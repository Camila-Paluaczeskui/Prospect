<?php
$dbhost     = "localhost";
$banco      = "bd_prospects";
$user       = "root";
$password   = "";
?>